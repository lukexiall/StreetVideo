## Harrell restricted cubic spline basis (as Hmisc::rcspline.eval, norm=2)
rcs_basis <- function(x, k) {
  nk <- length(k); out <- matrix(x, ncol = 1)
  den <- (k[nk] - k[1])^2
  for (j in 1:(nk - 2)) {
    out <- cbind(out, (pmax(x - k[j], 0)^3 - pmax(x - k[nk - 1], 0)^3 * (k[nk] - k[j]) / (k[nk] - k[nk - 1]) +
                         pmax(x - k[nk], 0)^3 * (k[nk - 1] - k[j]) / (k[nk] - k[nk - 1])) / den)
  }
  out
}
kq <- list(`3` = c(.10, .5, .90), `4` = c(.05, .35, .65, .95), `5` = c(.05, .275, .5, .725, .95))
knots_for <- function(v, nk) as.numeric(quantile(v, kq[[as.character(nk)]], type = 7))

## standardise continuous covariates; keep SDs for back-transformation
cont <- c(temp = "air_temp_BoM_S4_C", FAR = "FAR", mix = "functional_mix", HW = "HW_ratio",
          foot = "footpath_m", POI = "POI_per100m", vol = "pedestrian_volume_session")
SD <- sapply(cont, function(v) sd(p[[v]]))
for (n in names(cont)) p[[paste0("z_", n)]] <- as.numeric(scale(p[[cont[n]]]))
incr <- c(z_temp = 5, z_FAR = 1, z_mix = 0.1, z_HW = 0.1, z_foot = 1, z_POI = 1)

temporal <- "season + period + day_type + z_temp"
built <- "z_FAR + z_mix + z_HW + z_foot + seating + outdoor_dining + z_POI + bus_stop + crossing"
sets <- list(Base = "street", Temporal = paste("street", temporal, sep = " + "),
             Built = paste("street", built, sep = " + "),
             Full = paste("street", temporal, built, sep = " + "))

fitmod <- function(dat, rhs, expo, knots, dist) {
  B <- rcs_basis(dat[[expo]], knots); colnames(B) <- paste0("gvi", seq_len(ncol(B)))
  dat <- cbind(dat, B)
  f <- as.formula(paste("Surv(duration_s, departure_status) ~", paste(colnames(B), collapse = " + "),
                        "+", rhs, "+ (1 | segment) + (1 | session)"))
  t0 <- Sys.time()
  m <- SurvregME(f, data = dat, dist = dist, control = optim_control(iter.max = 5000, eval.max = 10000, rel.tol = 1e-10, ntry = 10))
  list(m = m, dat = dat, knots = knots, nb = ncol(B), secs = as.numeric(Sys.time() - t0, units = "secs"))
}

summ <- function(fm, rhs, dist, levels = c(5, 10, 15, 20, 25, 30), grid = NULL) {
  cb <- coef(fm$m, with_baseline = TRUE); np <- names(cb)
  V <- vcov(fm$m)[np, np]
  th1 <- np[1]; th2 <- np[2]; s2 <- cb[th2]
  gi <- paste0("gvi", 1:fm$nb)
  w <- function(ix) as.numeric(t(cb[ix]) %*% solve(V[ix, ix]) %*% cb[ix])
  w_all <- w(gi); nl <- gi[-1]; w_nl <- w(nl)
  X <- model.matrix(as.formula(paste("~", rhs)), fm$dat)[, -1, drop = FALSE]
  other <- setdiff(np[-(1:2)], gi); stopifnot(all(other %in% colnames(X)))
  X <- X[, other, drop = FALSE]
  cst <- if (dist == "weibull") log(log(2)) else 0
  eo <- as.numeric(X %*% cb[other])
  pred <- function(gv) {
    bg <- rcs_basis(gv, fm$knots)
    t(sapply(seq_along(gv), function(j) {
      L <- (cst - cb[th1] + sum(bg[j, ] * cb[gi]) + eo) / s2
      m <- max(L); wt <- exp(L - m); wt <- wt / sum(wt); lp <- m + log(mean(exp(L - m)))
      gr <- setNames(numeric(length(np)), np)
      gr[th1] <- -1 / s2; gr[gi] <- bg[j, ] / s2; gr[other] <- colSums(X * wt) / s2; gr[th2] <- -sum(wt * L) / s2
      c(lp = lp, se = sqrt(as.numeric(t(gr) %*% V %*% gr)))
    }))
  }
  contrast <- function(g1, g0) {
    d <- as.numeric(rcs_basis(g1, fm$knots) - rcs_basis(g0, fm$knots))
    est <- sum(d * cb[gi]) / s2
    gr <- setNames(numeric(length(np)), np); gr[gi] <- d / s2; gr[th2] <- -est / s2
    se <- sqrt(as.numeric(t(gr) %*% V %*% gr))
    c(TR = exp(est), lo = exp(est - 1.96 * se), hi = exp(est + 1.96 * se), P = 2 * pnorm(-abs(est / se)))
  }
  pr <- pred(levels)
  tab4 <- data.frame(GVI = levels, med = exp(pr[, "lp"]), lo = exp(pr[, "lp"] - 1.96 * pr[, "se"]),
                     hi = exp(pr[, "lp"] + 1.96 * pr[, "se"]))
  tab4 <- cbind(tab4, t(sapply(levels, function(l) contrast(l, 5))))
  res <- list(W_all = w_all, df_all = fm$nb, P_all = pchisq(w_all, fm$nb, lower.tail = FALSE),
              W_nl = w_nl, df_nl = length(nl), P_nl = pchisq(w_nl, length(nl), lower.tail = FALSE),
              c20v10 = contrast(20, 10), tab4 = tab4, secs = fm$secs, sigma = 1 / s2,
              logLik = as.numeric(logLik(fm$m)), conv = fm$m$opt$convergence, warn = paste(fm$m$opt$warnings, collapse = ";"))
  if (!is.null(grid)) { pg <- pred(grid); res$curve <- data.frame(GVI = grid, med = exp(pg[, "lp"]),
                          lo = exp(pg[, "lp"] - 1.96 * pg[, "se"]), hi = exp(pg[, "lp"] + 1.96 * pg[, "se"])) }
  res$covTR <- do.call(rbind, lapply(other, function(k) {
    mult <- if (k %in% names(incr)) incr[k] / SD[sub("z_", "", k)] else 1
    est <- cb[k] / s2 * mult
    gr <- setNames(numeric(length(np)), np); gr[k] <- mult / s2; gr[th2] <- -est / s2
    se <- sqrt(as.numeric(t(gr) %*% V %*% gr))
    data.frame(term = k, TR = exp(est), lo = exp(est - 1.96 * se), hi = exp(est + 1.96 * se), P = 2 * pnorm(-abs(est / se)))
  }))
  res
}

