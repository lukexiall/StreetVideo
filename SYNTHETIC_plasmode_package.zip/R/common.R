## Shared setup: identical data preparation to Supplementary_code/fit.R (lines 7-12),
## then sources lines 14-98 of fit2.R (stricter optimiser) verbatim (spline basis, knots, standardisation, fitmod, summ).
suppressPackageStartupMessages({library(tramME); library(survival); library(readxl)})
load_data <- function(xlsx) {
  p <- as.data.frame(read_excel(xlsx, "Pedestrians")); g <- as.data.frame(read_excel(xlsx, "GVI"))
  p$street   <- relevel(factor(p$street), "Hindley")
  p$season   <- relevel(factor(p$season), "spring")
  p$period   <- relevel(factor(p$period), "morning")
  p$day_type <- relevel(factor(p$day_type), "weekday")
  p$segment <- factor(p$segment); p$session <- factor(p$session)
  list(p = p, g = g)
}
