## Step 2: plasmode simulation. ONLY duration_s is regenerated; all other fields
## (incl. departure_status, covariates, row order) are the real values.
## Design (pre-specified): rows with departure_status==1 get
##   log T = (-th1 + X*beta + u_segment + u_session + eps)/th2,  eps ~ N(0,1)
## using the Primary-model coefficients from 01 (truth template), except the GVI spline
## coefficients, which are set by scenario. Rows with departure_status==0 keep their observed
## (censoring) time, because status may not be changed. Durations rounded to 0.01 s as in source.
## Mode "emp" (semi-parametric, recommended): random effects = real-data BLUPs and eps resampled
## with replacement from the real-data latent residuals (01b), instead of N(0,1) / N(0,sd^2).
## Usage: Rscript 02_plasmode.R <data.xlsx> <out_dir> <scenario> <rep> [normal|emp]
a <- commandArgs(TRUE); here <- dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE)))
source(file.path(here, "common.R")); D <- load_data(a[1]); p <- D$p; g <- D$g; od <- a[2]
sc <- a[3]; rep <- as.integer(a[4]); mode <- if (length(a) > 4) a[5] else "normal"
source(file.path(here, "fit_lib_from_fit.R"))
T0 <- readRDS(file.path(od, "truth_template.rds")); cb <- T0$coef; K4 <- T0$knots
gi <- paste0("gvi", 1:3); th1 <- names(cb)[1]; th2 <- names(cb)[2]
## scenario-specific GVI coefficients (defined before any simulated fit; not tuned)
b <- cb[gi]
lin <- log(T0$real_summary$c20v10[1]) * cb[th2] / 10           # same 20v10 TR, straight line
bg <- switch(sc, S0_null = c(0, 0, 0), S1_linear = c(lin, 0, 0),
             S2_asfitted = b, S3_nonlin_x2 = c(b[1], 2 * b[2], 2 * b[3]), stop("scenario"))
cbT <- cb; cbT[gi] <- bg
set.seed(1e4 * match(sc, c("S0_null", "S1_linear", "S2_asfitted", "S3_nonlin_x2")) + rep)
B <- rcs_basis(p$GVI_seasonal, K4); colnames(B) <- gi
X <- model.matrix(as.formula(paste("~", sets$Full)), p)[, -1, drop = FALSE]
other <- setdiff(names(cb)[-(1:2)], gi)
eta <- -cbT[th1] + B %*% cbT[gi] + X[, other] %*% cbT[other]
useg <- rnorm(nlevels(p$segment), 0, T0$sd_segment)[as.integer(p$segment)]
uses <- rnorm(nlevels(p$session), 0, T0$sd_session)[as.integer(p$session)]
eps <- rnorm(nrow(p))
if (mode == "emp") { RR <- readRDS(file.path(od, "residuals_real.rds")); useg <- RR$u_seg; uses <- RR$u_ses
  eps <- sample(RR$resid, nrow(p), replace = TRUE) }
tsim <- round(exp((as.numeric(eta) + useg + uses + eps) / cbT[th2]), 2)
tsim <- pmax(tsim, 0.01)
ev <- p$departure_status == 1
orig <- p$duration_s; p$duration_s[ev] <- tsim[ev]
tag <- sprintf("%s%s_rep%02d", if (mode == "emp") "EMP_" else "", sc, rep)
saveRDS(list(row = which(ev) + 1L, old = orig[ev], new = p$duration_s[ev]), file.path(od, paste0("dur_", tag, ".rds")))
fm <- fitmod(p, sets$Full, "GVI_seasonal", K4, "lognormal")
r <- summ(fm, sets$Full, "lognormal")
## true values on the same scale as summ(): conditional 20v10 TR and covariate TRs
d <- as.numeric(rcs_basis(20, K4) - rcs_basis(10, K4))
true <- list(TR20v10 = exp(sum(d * bg) / cb[[th2]]),
             nonlinear = any(bg[2:3] != 0), gvi_effect = any(bg != 0))
r$true <- true; r$scenario <- paste0(if (mode == "emp") "EMP_" else "", sc); r$rep <- rep; r$conv <- fm$m$opt$convergence
saveRDS(r, file.path(od, paste0("fit_", tag, ".rds")))
cat(sprintf("%s conv=%s TR=%.4f [%.4f,%.4f] true=%.4f Pall=%.4g Pnl=%.4g secs=%.0f\n", tag, r$conv,
            r$c20v10[1], r$c20v10[2], r$c20v10[3], true$TR20v10, r$P_all, r$P_nl, fm$secs))
