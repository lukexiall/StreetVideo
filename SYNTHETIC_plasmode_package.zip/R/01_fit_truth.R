## Step 1: refit the published Primary model on the REAL data (reproducibility check),
## and save its parameters as the plasmode "truth" template.
## Usage: Rscript 01_fit_truth.R <data.xlsx> <out_dir>
a <- commandArgs(TRUE); here <- dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE)))
source(file.path(here, "common.R")); D <- load_data(a[1]); p <- D$p; g <- D$g; od <- a[2]
source(file.path(here, "fit_lib_from_fit.R"))
K4 <- knots_for(g$GVI_seasonal, 4)
fm <- fitmod(p, sets$Full, "GVI_seasonal", K4, "lognormal")
r <- summ(fm, sets$Full, "lognormal")
vc <- VarCorr(fm$m)
truth <- list(coef = coef(fm$m, with_baseline = TRUE),
              sd_segment = sqrt(as.numeric(vc$segment$var)), sd_session = sqrt(as.numeric(vc$session$var)),
              knots = K4, real_summary = r, conv = fm$m$opt$convergence)
saveRDS(truth, file.path(od, "truth_template.rds"))
cat(sprintf("REAL refit: TR20v10=%.4f (%.4f-%.4f) P_all=%.5f P_nl=%.5f sigma=%.4f secs=%.0f\n",
            r$c20v10[1], r$c20v10[2], r$c20v10[3], r$P_all, r$P_nl, r$sigma, fm$secs))
print(truth$coef); cat("sd_segment", truth$sd_segment, "sd_session", truth$sd_session, "\n")
