"""Export one plasmode replicate as a SYNTHETIC workbook + per-row change log + diagnostics.
Only Pedestrians!duration_s is written; every other cell/sheet is copied from the source.
Usage: python3 export_synthetic.py <source.xlsx> <durations.csv> <out_dir> <tag>
durations.csv columns: row (Excel row number), old, new
"""
import sys, pandas as pd, openpyxl
src, dur, od, tag = sys.argv[1:5]
d = pd.read_csv(dur)
wb = openpyxl.load_workbook(src)
ws = wb["Pedestrians"]
hdr = [c.value for c in ws[1]]; col = hdr.index("duration_s") + 1
for r, new in zip(d.row, d.new):
    ws.cell(row=int(r), column=col).value = float(new)
wb.properties.title = f"SYNTHETIC plasmode replicate {tag} - NOT REAL OBSERVATIONS"
wb.properties.subject = "duration_s simulated from a known model; for method testing only"
wb.save(f"{od}/SYNTHETIC_plasmode_{tag}.xlsx")
d.assign(reason="plasmode: duration_s regenerated from pre-specified known model (event rows only)") \
 .to_csv(f"{od}/SYNTHETIC_change_log_{tag}.csv.gz", index=False)

o = pd.read_excel(src, "Pedestrians"); s = o.copy(); s.loc[d.row - 2, "duration_s"] = d.new.values
assert (o.drop(columns="duration_s").equals(s.drop(columns="duration_s")))
def diag(p, name):
    q = p.groupby("session").duration_s.quantile([.25, .75]).unstack()
    iqr = q[.75] - q[.25]
    ties = p.groupby("session").duration_s.apply(lambda x: 1 - x.nunique() / len(x))
    return {"data": name, "exact_duplicate_rows": int(p.duplicated().sum()),
            "sessions_IQR_lt_0.5s": int((iqr < .5).sum()), "median_session_IQR": iqr.median(),
            "max_session_tie_share": ties.max(), "median": p.duration_s.median(),
            "Q1": p.duration_s.quantile(.25), "Q3": p.duration_s.quantile(.75)}
pd.DataFrame([diag(o, "original"), diag(s, f"SYNTHETIC {tag}")]).to_csv(f"{od}/distribution_diagnostics_{tag}.csv", index=False)
for k in ["H24", "G19", "G20"]:
    for p, n in [(o, "orig"), (s, "syn")]:
        x = p[p.segment == k].duration_s
        print(k, n, len(x), x.quantile([.25, .5, .75]).round(2).tolist(), "unique", x.nunique())
print(pd.read_csv(f"{od}/distribution_diagnostics_{tag}.csv").T.to_string())
print("rows changed", len(d), "of", len(o), f"({100*len(d)/len(o):.1f}%)")
