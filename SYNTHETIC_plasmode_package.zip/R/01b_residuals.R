## Step 1b (semi-parametric plasmode): refit Primary on REAL data, keep BLUPs of the
## segment/session random effects and the latent-scale residuals of event rows:
##   e_i = th2*log(t_i) + th1 - X_i beta - u_seg - u_ses    (departure_status == 1)
## Usage: Rscript 01b_residuals.R <data.xlsx> <out_dir>
a <- commandArgs(TRUE); here <- dirname(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE)))
source(file.path(here, "common.R")); D <- load_data(a[1]); p <- D$p; g <- D$g; od <- a[2]
source(file.path(here, "fit_lib_from_fit.R"))
T0 <- readRDS(file.path(od, "truth_template.rds")); K4 <- T0$knots
fm <- fitmod(p, sets$Full, "GVI_seasonal", K4, "lognormal"); cb <- coef(fm$m, with_baseline = TRUE)
stopifnot(fm$m$opt$convergence == 0, isTRUE(all.equal(cb, T0$coef, tolerance = 1e-2)))
cat("max |coef diff| vs truth template:", max(abs(cb - T0$coef)), "\n")
re <- ranef(fm$m); us <- re$segment[as.character(p$segment), 1]; uz <- re$session[as.character(p$session), 1]
gi <- paste0("gvi", 1:3); B <- rcs_basis(p$GVI_seasonal, K4)
X <- model.matrix(as.formula(paste("~", sets$Full)), p)[, -1, drop = FALSE]; other <- setdiff(names(cb)[-(1:2)], gi)
xb <- as.numeric(B %*% cb[gi] + X[, other] %*% cb[other])
ev <- p$departure_status == 1
e_plus  <- cb[2] * log(p$duration_s) + cb[1] - xb - us - uz
e_minus <- cb[2] * log(p$duration_s) + cb[1] - xb + us + uz
cat("sign check: sd(e|+u)=", sd(e_plus[ev]), " sd(e|-u)=", sd(e_minus[ev]), "\n")
e <- if (sd(e_plus[ev]) <= sd(e_minus[ev])) e_plus else e_minus; sgn <- if (identical(e, e_plus)) 1 else -1
saveRDS(list(resid = e[ev], u_seg = sgn * us, u_ses = sgn * uz), file.path(od, "residuals_real.rds"))
cat("residuals: mean", mean(e[ev]), "sd", sd(e[ev]), "quantiles", quantile(e[ev], c(.01,.25,.5,.75,.99)), "\n")
