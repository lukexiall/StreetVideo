## Step 3: performance summary per scenario (pre-specified metrics):
## bias and relative bias of log TR(20 vs 10), 95% CI coverage, rejection rate of the
## overall and non-linear Wald tests at alpha=0.05, convergence count.
## Usage: Rscript 03_summarise.R <out_dir>
od <- commandArgs(TRUE)[1]
fs <- list.files(od, "^fit_.*\\.rds$", full.names = TRUE)
R <- do.call(rbind, lapply(fs, function(f) { r <- readRDS(f)
  data.frame(scenario = r$scenario, rep = r$rep, conv = r$conv, TR = r$c20v10[1], lo = r$c20v10[2],
             hi = r$c20v10[3], P_all = r$P_all, P_nl = r$P_nl, true_TR = r$true$TR20v10,
             seating_TR = r$covTR$TR[r$covTR$term == "seating"], dining_TR = r$covTR$TR[r$covTR$term == "outdoor_dining"],
             sigma = r$sigma) }))
write.csv(R, file.path(od, "plasmode_replicates.csv"), row.names = FALSE)
S <- do.call(rbind, lapply(split(R, R$scenario), function(d) data.frame(
  scenario = d$scenario[1], n_rep = nrow(d), n_converged = sum(d$conv == 0), true_TR20v10 = d$true_TR[1],
  mean_est_TR = exp(mean(log(d$TR))), bias_logTR = mean(log(d$TR) - log(d$true_TR)),
  rel_bias_pct = 100 * (exp(mean(log(d$TR) - log(d$true_TR))) - 1),
  CI_coverage = mean(d$lo <= d$true_TR & d$true_TR <= d$hi),
  reject_overall_0.05 = mean(d$P_all < .05), reject_nonlinear_0.05 = mean(d$P_nl < .05),
  median_P_nl = median(d$P_nl))))
write.csv(S, file.path(od, "plasmode_summary.csv"), row.names = FALSE); print(S, digits = 3)
## Comparison with the REAL-data Primary fit (= Cities final manuscript, reproduced in 01):
## every covariate TR and every Table-4 predicted median, mean over replicates, abs & rel diff.
T0 <- readRDS(file.path(od, "truth_template.rds"))$real_summary
cmp <- do.call(rbind, lapply(split(fs, sapply(fs, function(f) readRDS(f)$scenario)), function(ff) {
  L <- lapply(ff, readRDS); sc <- L[[1]]$scenario
  cov <- sapply(L, function(r) r$covTR$TR); med <- sapply(L, function(r) r$tab4$med)
  rbind(data.frame(scenario = sc, item = paste0("TR_", T0$covTR$term), paper = T0$covTR$TR, sim_mean = rowMeans(cov)),
        data.frame(scenario = sc, item = paste0("median_GVI", T0$tab4$GVI), paper = T0$tab4$med, sim_mean = rowMeans(med)),
        data.frame(scenario = sc, item = c("TR20v10", "P_overall", "P_nonlinear", "sigma"),
                   paper = c(T0$c20v10[1], T0$P_all, T0$P_nl, T0$sigma),
                   sim_mean = c(exp(mean(sapply(L, function(r) log(r$c20v10[1])))), median(sapply(L, `[[`, "P_all")),
                                median(sapply(L, `[[`, "P_nl")), mean(sapply(L, `[[`, "sigma"))))) }))
cmp$abs_diff <- cmp$sim_mean - cmp$paper; cmp$rel_diff_pct <- 100 * cmp$abs_diff / cmp$paper
write.csv(cmp, file.path(od, "comparison_vs_paper.csv"), row.names = FALSE)
