# SYNTHETIC plasmode simulation - NOT REAL OBSERVATIONS
Purpose: test the Cities primary AFT model (fit2.R settings) on data with KNOWN truth.
Not for submission; simulated values must never be reported as observations.

## Design (only Pedestrians!duration_s changed)
- Rows with departure_status==1 (125,748 / 138,873 = 90.5%): duration regenerated as
  log T = (-th1 + X*beta + u_seg + u_ses + eps)/th2. beta = real-data Primary fit; GVI spline by scenario.
- EMP (semi-parametric, main): u = real-data BLUPs, eps resampled from real-data residuals.
  "normal" variant (comparison, incomplete reps): u ~ N(0, sd), eps ~ N(0,1).
- Censored rows (status 0) keep observed time (status may not change). All other cells unchanged (asserted).
- Scenarios: S0 no GVI effect; S1 linear (same TR20v10); S2 as fitted; S3 non-linear terms x2.
  Parameters fixed before simulation; replicates not selected by results. Seeds in 02_plasmode.R.

## Files
SYNTHETIC_plasmode_EMP_S2_asfitted_rep01.xlsx  example dataset (workbook title marked SYNTHETIC)
SYNTHETIC_change_log_*.csv.gz   Excel row, old, new, reason for every changed cell
distribution_diagnostics_*.csv  duplicates, session IQR<0.5 s, ties, quartiles before/after
out/plasmode_summary.csv        bias, coverage, rejection rates per scenario
out/plasmode_replicates.csv     every fit;  out/comparison_vs_paper.csv  every TR/median vs paper fit
out/*.log                       actual R output; scorecard.csv  pre-stated formulas (see 00 below)
R/01_fit_truth.R -> 01b_residuals.R -> 02_plasmode.R <xlsx> out <scenario> <rep> emp -> 03_summarise.R

## Scorecard formulas (method-testing, not R1-matching)
1 20*converged/total; 2 20*(1-max(0,|bias%|-2)/8); 3 15*coverage; 4 15*(1-max(0,typeI-0.05)/0.45);
5 15*(1-mean|rel diff Q1,median,Q3|/50%); 6 15*(1-median|rel diff|/10%).
Caveats: 10 reps/scenario (MC error large); score formulas written by the analyst, not by an external referee.
